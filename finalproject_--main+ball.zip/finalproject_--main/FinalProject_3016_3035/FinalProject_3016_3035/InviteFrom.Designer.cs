﻿namespace FinalProject_3016_3035
{
    partial class InviteFrom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.txtSystemMessage = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.txtServerPort = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txtServerIP = new System.Windows.Forms.Label();
            this.txtPlayerName = new System.Windows.Forms.Label();
            this.Timer1 = new System.Windows.Forms.Timer(this.components);
            this.G = new System.Windows.Forms.Panel();
            this.H1 = new System.Windows.Forms.Label();
            this.H2 = new System.Windows.Forms.Label();
            this.LabelOpponentScore = new System.Windows.Forms.Label();
            this.LabelPlayerScore = new System.Windows.Forms.Label();
            this.Q = new System.Windows.Forms.Label();
            this.G.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(530, 410);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 24);
            this.label1.TabIndex = 223;
            this.label1.Text = "遊戲輪數：";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button3.Location = new System.Drawing.Point(529, 452);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(189, 34);
            this.button3.TabIndex = 222;
            this.button3.Text = "邀請玩家";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("新細明體", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.comboBox1.Location = new System.Drawing.Point(639, 411);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox1.MaxLength = 5;
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(79, 25);
            this.comboBox1.TabIndex = 221;
            this.comboBox1.Text = "1";
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("微軟正黑體", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 23;
            this.listBox1.Location = new System.Drawing.Point(529, 253);
            this.listBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(191, 142);
            this.listBox1.TabIndex = 220;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("微軟正黑體", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Label4.Location = new System.Drawing.Point(530, 227);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(105, 24);
            this.Label4.TabIndex = 219;
            this.Label4.Text = "線上使用者";
            // 
            // txtSystemMessage
            // 
            this.txtSystemMessage.AutoSize = true;
            this.txtSystemMessage.Font = new System.Drawing.Font("微軟正黑體", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtSystemMessage.Location = new System.Drawing.Point(23, 560);
            this.txtSystemMessage.Name = "txtSystemMessage";
            this.txtSystemMessage.Size = new System.Drawing.Size(86, 24);
            this.txtSystemMessage.TabIndex = 218;
            this.txtSystemMessage.Text = "系統訊息";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button2.Location = new System.Drawing.Point(529, 540);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(189, 79);
            this.button2.TabIndex = 217;
            this.button2.Text = "開始遊戲";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("微軟正黑體", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox4.Location = new System.Drawing.Point(26, 584);
            this.textBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(388, 32);
            this.textBox4.TabIndex = 216;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微軟正黑體", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.Location = new System.Drawing.Point(529, 495);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(189, 34);
            this.button1.TabIndex = 215;
            this.button1.Text = "重新開始";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("微軟正黑體", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox3.Location = new System.Drawing.Point(529, 185);
            this.textBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(176, 32);
            this.textBox3.TabIndex = 214;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("微軟正黑體", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox2.Location = new System.Drawing.Point(529, 116);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(173, 32);
            this.textBox2.TabIndex = 212;
            this.textBox2.Text = "2024";
            // 
            // txtServerPort
            // 
            this.txtServerPort.AutoSize = true;
            this.txtServerPort.Font = new System.Drawing.Font("微軟正黑體", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtServerPort.Location = new System.Drawing.Point(525, 90);
            this.txtServerPort.Name = "txtServerPort";
            this.txtServerPort.Size = new System.Drawing.Size(125, 24);
            this.txtServerPort.TabIndex = 211;
            this.txtServerPort.Text = "伺服器Port：";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("微軟正黑體", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox1.Location = new System.Drawing.Point(529, 45);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(173, 32);
            this.textBox1.TabIndex = 210;
            // 
            // txtServerIP
            // 
            this.txtServerIP.AutoSize = true;
            this.txtServerIP.Font = new System.Drawing.Font("微軟正黑體", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtServerIP.Location = new System.Drawing.Point(526, 19);
            this.txtServerIP.Name = "txtServerIP";
            this.txtServerIP.Size = new System.Drawing.Size(104, 24);
            this.txtServerIP.TabIndex = 209;
            this.txtServerIP.Text = "伺服器IP：";
            // 
            // txtPlayerName
            // 
            this.txtPlayerName.AutoSize = true;
            this.txtPlayerName.Font = new System.Drawing.Font("微軟正黑體", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtPlayerName.Location = new System.Drawing.Point(530, 159);
            this.txtPlayerName.Name = "txtPlayerName";
            this.txtPlayerName.Size = new System.Drawing.Size(105, 24);
            this.txtPlayerName.TabIndex = 213;
            this.txtPlayerName.Text = "玩家名稱：";
            // 
            // G
            // 
            this.G.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.G.Controls.Add(this.H1);
            this.G.Controls.Add(this.Q);
            this.G.Controls.Add(this.H2);
            this.G.Location = new System.Drawing.Point(13, 18);
            this.G.Margin = new System.Windows.Forms.Padding(4);
            this.G.Name = "G";
            this.G.Size = new System.Drawing.Size(480, 500);
            this.G.TabIndex = 224;
            // 
            // H1
            // 
            this.H1.BackColor = System.Drawing.Color.MidnightBlue;
            this.H1.Location = new System.Drawing.Point(187, 458);
            this.H1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.H1.Name = "H1";
            this.H1.Size = new System.Drawing.Size(107, 25);
            this.H1.TabIndex = 4;
            this.H1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.H1_MouseDown);
            this.H1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.H1_MouseMove);
            // 
            // H2
            // 
            this.H2.BackColor = System.Drawing.Color.Red;
            this.H2.Location = new System.Drawing.Point(187, 19);
            this.H2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.H2.Name = "H2";
            this.H2.Size = new System.Drawing.Size(107, 25);
            this.H2.TabIndex = 5;
            // 
            // LabelOpponentScore
            // 
            this.LabelOpponentScore.AutoSize = true;
            this.LabelOpponentScore.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LabelOpponentScore.Location = new System.Drawing.Point(325, 537);
            this.LabelOpponentScore.Name = "LabelOpponentScore";
            this.LabelOpponentScore.Size = new System.Drawing.Size(89, 20);
            this.LabelOpponentScore.TabIndex = 226;
            this.LabelOpponentScore.Text = "對手得分";
            // 
            // LabelPlayerScore
            // 
            this.LabelPlayerScore.AutoSize = true;
            this.LabelPlayerScore.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LabelPlayerScore.Location = new System.Drawing.Point(183, 537);
            this.LabelPlayerScore.Name = "LabelPlayerScore";
            this.LabelPlayerScore.Size = new System.Drawing.Size(89, 20);
            this.LabelPlayerScore.TabIndex = 225;
            this.LabelPlayerScore.Text = "我方得分";
            // 
            // Q
            // 
            this.Q.Image = global::FinalProject_3016_3035.Properties.Resources._661655143c0e51;
            this.Q.Location = new System.Drawing.Point(209, 224);
            this.Q.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Q.Name = "Q";
            this.Q.Size = new System.Drawing.Size(40, 40);
            this.Q.TabIndex = 6;
            // 
            // InviteFrom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(741, 635);
            this.Controls.Add(this.LabelOpponentScore);
            this.Controls.Add(this.LabelPlayerScore);
            this.Controls.Add(this.G);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.txtSystemMessage);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.txtServerPort);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.txtServerIP);
            this.Controls.Add(this.txtPlayerName);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "InviteFrom";
            this.Text = "Invite";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.G.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox comboBox1;
        internal System.Windows.Forms.ListBox listBox1;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label txtSystemMessage;
        internal System.Windows.Forms.Button button2;
        internal System.Windows.Forms.TextBox textBox4;
        internal System.Windows.Forms.Button button1;
        internal System.Windows.Forms.TextBox textBox3;
        internal System.Windows.Forms.TextBox textBox2;
        internal System.Windows.Forms.Label txtServerPort;
        internal System.Windows.Forms.TextBox textBox1;
        internal System.Windows.Forms.Label txtServerIP;
        internal System.Windows.Forms.Label txtPlayerName;
        internal System.Windows.Forms.Timer Timer1;
        internal System.Windows.Forms.Panel G;
        internal System.Windows.Forms.Label H1;
        internal System.Windows.Forms.Label Q;
        internal System.Windows.Forms.Label H2;
        private System.Windows.Forms.Label LabelOpponentScore;
        private System.Windows.Forms.Label LabelPlayerScore;
    }
}